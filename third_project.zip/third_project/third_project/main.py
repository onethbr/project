from flask_sqlalchemy import SQLAlchemy
from flask import Flask, render_template, redirect, request
from flask_wtf import FlaskForm
from wtforms import SubmitField, StringField, PasswordField, BooleanField
from flask_login import LoginManager, login_user, UserMixin, login_required, logout_user
from wtforms.validators import DataRequired

data_ = None


app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///habits.sqlite'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['SECRET_KEY'] = '_secret_key_'
db = SQLAlchemy(app)

login_manager = LoginManager()
login_manager.init_app(app)


class LoginForm(FlaskForm):
    name = StringField('Ник', validators=[DataRequired()])
    password = PasswordField('Пароль', validators=[DataRequired()])
    remember_me = BooleanField('Запомнить меня')
    submit = SubmitField('Войти')


class Habits(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(200), nullable=True)
    days = db.Column(db.Integer, nullable=True)
    status = db.Column(db.Boolean, unique=False, default=False)


class User(db.Model, UserMixin):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(200), nullable=True)
    password = db.Column(db.String(200), nullable=True)


@login_manager.user_loader
def load_user(user_id):
    return User.query.get(user_id)


@app.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect("/")


@app.route('/login', methods=['GET', 'POST'])
def login():
    form = LoginForm()
    if form.validate_on_submit():
        user = User.query.filter(User.username == form.name.data).first()
        if user and user.password == form.password.data:
            login_user(user, remember=form.remember_me.data)
            return redirect("/")
        return render_template('login.html',
                               message="Неправильный логин или пароль",
                               form=form)
    return render_template('login.html', form=form)


@app.route('/', methods=['GET', 'POST'])
def index():
    return render_template('index.html')


@app.route('/main', methods=['GET', 'POST'])
def main():
    if request.method == "POST":
        name = request.form['name']
        days = request.form['days']
        status = 0

        data = Habits(name=name, days=days, status=status)

        db.session.add(data)
        db.session.commit()

        return render_template('main.html')
    else:
        return render_template('main.html')


@app.route('/my_habits', methods=['GET', 'POST'])
def my_habits():
    global data_
    data_ = Habits.query.all()
    return render_template('my_habits.html', data_=data_)


@app.route('/finish/<int:habit>', methods=['GET', 'POST'])
def finish(habit):
    Habits.query.get(habit).status = True
    db.session.commit()
    return redirect('/my_habits')


@app.route('/reg', methods=['GET', 'POST'])
def reg():
    if request.method == "POST":
        username = request.form['username']
        password = request.form['password']

        user_reg = User(username=username, password=password)

        db.session.add(user_reg)
        db.session.commit()
        return redirect('/main')
    else:
        return render_template('register.html')


if __name__ == '__main__':
    app.run(port=8080, host='127.0.0.1')
